colorbrewer
===========

Color specifications and designs developed by Cynthia Brewer (http://colorbrewer2.org/).

This is a shim module of colorbrewer2 by Cythina Brewer for browserify.

It is also a shim for the [files provided in d3.js lib](https://github.com/mbostock/d3/tree/master/lib/colorbrewer).
